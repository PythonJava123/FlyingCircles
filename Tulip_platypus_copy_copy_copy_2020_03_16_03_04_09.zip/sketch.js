var bubbles = [];

function setup() {
  createCanvas(600,400);
  
  bubble1 = new Bubble();
  bubble2 = new Bubble();
  bubble3 = new Bubble();
  bubble4 = new Bubble();
  Pradyun_bubble = new Bubble();
  WhitehatJr_bubble = new Bubble();
  BUBBLE = new Bubble();
  
}

function draw() {
  background("pink");
  bubble1.move();
  bubble2.move();
  bubble3.move();
  bubble4.move();
  Pradyun_bubble.move();
  WhitehatJr_bubble.move();
  BUBBLE.move();
  
  bubble1.display();
  bubble2.display();
  bubble3.display();
  bubble4.display();
  Pradyun_bubble.display();
  WhitehatJr_bubble.display();
  BUBBLE.display();
  
}

    